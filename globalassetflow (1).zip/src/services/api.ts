import * as mockApi from '../mock/api';

// Set this to true when a real backend is ready
const USE_REAL_API = false;

const API_BASE_URL = '/api';

export const optimizeRoute = async (params: any) => {
  if (USE_REAL_API) {
    const response = await fetch(`${API_BASE_URL}/optimize-route`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return response.json();
  }
  return mockApi.mockOptimizeRoute(params);
};

export const compareRoutes = async (params: any) => {
  if (USE_REAL_API) {
    const response = await fetch(`${API_BASE_URL}/compare-routes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return response.json();
  }
  return mockApi.mockCompareRoutes(params);
};

export const simulateScenario = async (params: any) => {
  if (USE_REAL_API) {
    const response = await fetch(`${API_BASE_URL}/simulate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return response.json();
  }
  return mockApi.mockSimulateScenario(params);
};

export const getInsights = async () => {
  if (USE_REAL_API) {
    const response = await fetch(`${API_BASE_URL}/insights`);
    return response.json();
  }
  return mockApi.mockGetInsights();
};

export const getAssets = async () => {
  if (USE_REAL_API) {
    const response = await fetch(`${API_BASE_URL}/assets`);
    return response.json();
  }
  return mockApi.mockGetAssets();
};

export { MOCK_COUNTRIES } from '../mock/api';
