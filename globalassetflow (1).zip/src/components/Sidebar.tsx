import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutGrid, Network, History, Radio, Lightbulb, Settings, LogOut, Landmark } from "lucide-react";

export default function Sidebar() {
  const menu = [
    { name: "Overview", path: "/", icon: LayoutGrid },
    { name: "Routing Matrix", path: "/matrix", icon: Network },
    { name: "History", path: "/history", icon: History },
    { name: "Simulation (Coming Soon)", path: "/simulation", icon: Radio, comingSoon: true },
    { name: "Insights (Coming Soon)", path: "/insights", icon: Lightbulb, comingSoon: true },
  ];

  return (
    <div className="h-screen w-[260px] fixed left-0 top-0 bg-[#F8F6FC] flex flex-col justify-between py-8 px-4 border-r border-gray-100">
      
      {/* Top Section */}
      <div>
        {/* Logo */}
        <div className="flex items-center gap-3 px-2 mb-10">
          <div className="w-10 h-10 rounded-full bg-[#6D5DF5] flex items-center justify-center shrink-0 shadow-sm shadow-purple-500/20">
            <Landmark className="w-5 h-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold text-gray-900 leading-none tracking-tight">GAF</span>
            <span className="text-[10px] font-bold text-[#6D5DF5] tracking-widest mt-1 uppercase">Asset Flow</span>
          </div>
        </div>

        {/* Menu */}
        <div className="flex flex-col gap-1">
          {menu.map((item, index) => {
            const Icon = item.icon;
            
            if (item.comingSoon) {
              return (
                <div key={index} className="flex items-center gap-3 px-4 py-3 rounded-2xl text-gray-400 cursor-not-allowed">
                  <Icon size={18} />
                  <span className="text-sm font-medium">{item.name}</span>
                </div>
              );
            }

            return (
              <NavLink
                key={index}
                to={item.path}
                className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-2xl cursor-pointer transition-colors ${
                  isActive
                    ? "bg-[#EBE4FF] text-[#6D5DF5] font-semibold"
                    : "text-gray-500 hover:bg-gray-100 hover:text-gray-900 font-medium"
                }`}
              >
                <Icon size={18} />
                <span className="text-sm">{item.name}</span>
              </NavLink>
            );
          })}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="flex flex-col gap-1 border-t border-gray-200 pt-4 px-2">
        <button className="flex items-center gap-3 px-4 py-3 rounded-2xl text-gray-500 hover:bg-gray-100 hover:text-gray-900 transition-colors w-full text-left">
          <Settings size={18} />
          <span className="text-sm font-medium">Settings</span>
        </button>
        <button className="flex items-center gap-3 px-4 py-3 rounded-2xl text-[#E94E8B] hover:bg-red-50 transition-colors w-full text-left">
          <LogOut size={18} />
          <span className="text-sm font-medium">Logout</span>
        </button>
      </div>
    </div>
  );
}
