import React from 'react';
import { Activity } from 'lucide-react';
import PageWrapper from '../components/PageWrapper';

export default function Simulation() {
  return (
    <PageWrapper>
      <div className="space-y-6">
        <h1 className="text-2xl font-semibold text-gray-900">Simulation</h1>
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <div className="bg-white p-12 rounded-2xl shadow-sm border border-gray-200 flex flex-col items-center text-center max-w-md">
            <div className="w-16 h-16 bg-purple-100 text-[#7C6CF6] rounded-full flex items-center justify-center mb-6">
              <Activity className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Simulation Engine</h2>
            <p className="text-gray-500 mb-6">Advanced scenario modeling and stress testing features are currently in development.</p>
            <span className="bg-purple-100 text-[#7C6CF6] text-xs font-bold px-3 py-1 rounded-full tracking-wider">COMING SOON</span>
          </div>
        </div>
      </div>
    </PageWrapper>
  );
}
