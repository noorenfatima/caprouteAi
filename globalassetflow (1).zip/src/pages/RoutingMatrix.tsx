import React, { useState } from "react";
import { Sparkles, CheckCircle2, Wallet, ShieldCheck, TrendingUp, Zap, ArrowRight, CreditCard, SlidersHorizontal, Globe2, Shield, Zap as ZapIcon, Info } from "lucide-react";
import PageWrapper from '../components/PageWrapper';

export default function RoutingMatrix() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(false);

  const handleAnalyze = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setResult(true);
    }, 2500);
  };

  const inputStyles = "w-full bg-white border-none rounded-xl px-4 py-3.5 text-sm font-medium text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#6D5DF5]/20 shadow-sm";
  const labelStyles = "block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2";

  return (
    <PageWrapper>
      <div className="space-y-8">

        {/* HEADER */}
        <div>
          <h1 className="text-3xl font-bold text-[#2D2A4A] mb-2">
            {result ? "Route Optimization Complete" : "Route Parameters"}
          </h1>
          {!result && (
            <p className="text-gray-500 text-lg">
              Define your capital movement corridor.
            </p>
          )}
        </div>

        {/* FORM */}
        {!loading && !result && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* LEFT COLUMN */}
            <div className="col-span-1 lg:col-span-8 space-y-6">
              
              {/* CORE INPUTS */}
              <div className="bg-[#F8F6FC] rounded-[2rem] p-8">
                <div className="flex items-center gap-3 mb-6">
                  <CreditCard className="w-5 h-5 text-[#6D5DF5]" />
                  <h2 className="text-lg font-bold text-[#2D2A4A]">Core Inputs</h2>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className={labelStyles}>Amount</label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6D5DF5] font-bold">$</span>
                      <input
                        className={`${inputStyles} pl-8 text-lg`}
                        placeholder="0.00"
                        defaultValue="0.00"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className={labelStyles}>Source Country</label>
                      <select className={inputStyles}>
                        <option>United States (USD)</option>
                        <option>India (INR)</option>
                        <option>United Kingdom (GBP)</option>
                      </select>
                    </div>
                    <div>
                      <label className={labelStyles}>Destination Country</label>
                      <select className={inputStyles}>
                        <option>Brazil (BRL)</option>
                        <option>United Arab Emirates (AED)</option>
                        <option>Singapore (SGD)</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* CONTEXT INPUTS */}
              <div className="bg-[#F8F6FC] rounded-[2rem] p-8">
                <div className="flex items-center gap-3 mb-6">
                  <SlidersHorizontal className="w-5 h-5 text-[#6D5DF5]" />
                  <h2 className="text-lg font-bold text-[#2D2A4A]">Context Inputs</h2>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className={labelStyles}>Purpose of Transfer</label>
                    <select className={inputStyles}>
                      <option>Export</option>
                      <option>Service</option>
                      <option>Investment</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelStyles}>Business Size</label>
                    <select className={inputStyles}>
                      <option>Small</option>
                      <option>Medium</option>
                      <option>Large</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelStyles}>Priority</label>
                    <select className={inputStyles}>
                      <option>Cost</option>
                      <option>Time</option>
                      <option>Balanced</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelStyles}>Currency Handling</label>
                    <select className={inputStyles}>
                      <option>Convert</option>
                      <option>Hold</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* BOTTOM FEATURES */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="bg-white border border-gray-100 rounded-2xl p-5 flex items-center gap-4 shadow-sm">
                  <div className="w-10 h-10 rounded-full bg-[#F8F6FC] flex items-center justify-center shrink-0">
                    <Globe2 className="w-5 h-5 text-[#6D5DF5]" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[#2D2A4A]">190+ Jurisdictions</div>
                    <div className="text-[10px] text-gray-500 mt-0.5">Access local rails globally</div>
                  </div>
                </div>
                <div className="bg-white border border-gray-100 rounded-2xl p-5 flex items-center gap-4 shadow-sm">
                  <div className="w-10 h-10 rounded-full bg-[#F8F6FC] flex items-center justify-center shrink-0">
                    <Shield className="w-5 h-5 text-[#6D5DF5]" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[#2D2A4A]">Real-time KYC/AML</div>
                    <div className="text-[10px] text-gray-500 mt-0.5">Automated compliance checks</div>
                  </div>
                </div>
                <div className="bg-white border border-gray-100 rounded-2xl p-5 flex items-center gap-4 shadow-sm">
                  <div className="w-10 h-10 rounded-full bg-[#F8F6FC] flex items-center justify-center shrink-0">
                    <ZapIcon className="w-5 h-5 text-[#6D5DF5]" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[#2D2A4A]">Instant Settlements</div>
                    <div className="text-[10px] text-gray-500 mt-0.5">T+0 delivery on major pairs</div>
                  </div>
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN (Analysis Preview) */}
            <div className="col-span-1 lg:col-span-4">
              <div className="bg-[#F3E8FF] rounded-[2rem] p-8 h-full flex flex-col">
                <h2 className="text-xl font-bold text-[#2D2A4A] mb-8">Analysis Preview</h2>
                
                <div className="space-y-6 flex-1">
                  <div className="flex justify-between items-start">
                    <span className="text-sm text-gray-500 font-medium">Configured<br/>Route</span>
                    <div className="text-right">
                      <div className="text-sm font-bold text-[#2D2A4A]">USD → BRL</div>
                      <div className="text-[10px] font-bold text-[#6D5DF5] uppercase tracking-wider mt-1">Export<br/>Corridor</div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500 font-medium">Regulatory Tier</span>
                    <span className="bg-[#EBE4FF] text-[#6D5DF5] text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                      Tier 1 Compliant
                    </span>
                  </div>

                  <div className="bg-[#EBE4FF]/50 rounded-2xl p-5 flex gap-3 mt-8">
                    <Info className="w-5 h-5 text-[#6D5DF5] shrink-0" />
                    <p className="text-xs text-gray-600 font-medium leading-relaxed">
                      System will analyze 144 potential banking partners and liquidity pools based on your balanced priority.
                    </p>
                  </div>
                </div>

                <div className="mt-8">
                  <button
                    onClick={handleAnalyze}
                    className="w-full bg-[#6D5DF5] hover:bg-[#5B4BE0] text-white py-4 rounded-full font-bold flex items-center justify-center gap-2 transition-colors shadow-md shadow-purple-500/20"
                  >
                    Analyze Routes <ArrowRight className="w-5 h-5" />
                  </button>

                  <div className="mt-8">
                    <div className="flex items-end justify-between h-12 gap-1 px-2 opacity-50">
                      {[40, 60, 30, 80, 50, 100, 40, 90].map((height, i) => (
                        <div key={i} className="w-full bg-[#6D5DF5] rounded-t-sm" style={{ height: `${height}%` }}></div>
                      ))}
                    </div>
                    <div className="text-center text-[9px] font-bold text-gray-400 uppercase tracking-widest mt-3">
                      Real-Time Liquidity Scan
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* LOADING */}
        {loading && (
          <div className="bg-white rounded-[2rem] shadow-sm p-20 flex flex-col items-center justify-center space-y-6 border border-gray-100">
            <div className="relative">
              <div className="w-16 h-16 rounded-full border-4 border-[#EBE4FF]"></div>
              <div className="w-16 h-16 rounded-full border-4 border-[#6D5DF5] border-t-transparent animate-spin absolute top-0 left-0"></div>
            </div>
            <p className="text-gray-600 font-medium">
              Analyzing global capital routes...
            </p>
          </div>
        )}

        {/* RESULT */}
        {result && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* LEFT COLUMN (Map + Bottom Stats) */}
            <div className="col-span-1 lg:col-span-7 flex flex-col gap-6">
              
              {/* MAP CARD */}
              <div className="relative h-[480px] bg-[#625F70] rounded-[2rem] overflow-hidden shadow-sm flex flex-col">
                {/* Abstract Map Shapes */}
                <svg className="absolute w-[120%] h-[120%] top-[-10%] left-[-10%] opacity-30" viewBox="0 0 1000 500" fill="#B4AEE8">
                  <path d="M150,100 Q200,80 250,120 T300,150 Q250,200 200,180 T150,100 Z" />
                  <path d="M250,250 Q300,280 280,350 T220,400 Q200,300 250,250 Z" />
                  <path d="M450,100 Q500,80 550,120 T500,250 Q450,350 480,400 T420,300 Q400,200 450,100 Z" />
                  <path d="M550,100 Q700,50 800,150 T750,250 Q650,200 550,100 Z" />
                  <path d="M750,350 Q800,320 850,380 T750,420 Q700,380 750,350 Z" />
                </svg>
                
                {/* Route Lines & Points */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1000 500">
                  <path d="M 220 160 Q 450 120 520 180 T 750 220" fill="none" stroke="#7C6CF6" strokeWidth="3" strokeDasharray="8 8" className="animate-pulse" />
                  <circle cx="220" cy="160" r="6" fill="#7C6CF6" />
                  <text x="220" y="180" fill="#B4AEE8" fontSize="12" textAnchor="middle" fontWeight="bold">New York, USA</text>
                  
                  <circle cx="520" cy="180" r="6" fill="#7C6CF6" />
                  <text x="520" y="200" fill="#B4AEE8" fontSize="12" textAnchor="middle" fontWeight="bold">Dubai, UAE</text>
                  
                  <circle cx="750" cy="220" r="6" fill="#7C6CF6" />
                  <text x="750" y="240" fill="#B4AEE8" fontSize="12" textAnchor="middle" fontWeight="bold">Singapore</text>
                  
                  <path d="M 750 220 Q 650 280 600 250" fill="none" stroke="#7C6CF6" strokeWidth="3" strokeDasharray="8 8" className="animate-pulse" />
                  <circle cx="600" cy="250" r="6" fill="#7C6CF6" />
                  <text x="600" y="270" fill="#B4AEE8" fontSize="12" textAnchor="middle" fontWeight="bold">Mumbai, IN</text>
                </svg>

                {/* Watermark */}
                <div className="absolute bottom-6 right-8 text-white/10 font-bold tracking-[0.3em] text-2xl pointer-events-none">
                  GLOBAL SAFE WORK
                </div>

                {/* Live Route Status Overlay */}
                <div className="absolute bottom-6 left-6 bg-white/90 backdrop-blur-sm p-5 rounded-2xl shadow-lg min-w-[200px]">
                  <h4 className="text-sm font-bold text-gray-900 mb-2">Live Route Status</h4>
                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                    <div className="w-2 h-2 rounded-full bg-[#7C6CF6]"></div>
                    Asset flow: Verified
                  </div>
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                    OPTIMIZED AT 10:42 AM GMT
                  </div>
                </div>
              </div>

              {/* BOTTOM STATS */}
              <div className="grid grid-cols-2 gap-6">
                {/* Liquidity Pool */}
                <div className="bg-white border border-gray-100 rounded-3xl p-6 flex items-center gap-5 shadow-sm">
                  <div className="w-14 h-14 rounded-full bg-[#EBE4FF] flex items-center justify-center shrink-0">
                    <Wallet className="w-6 h-6 text-[#7C6CF6]" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Liquidity Pool</div>
                    <div className="text-2xl font-bold text-[#2D2A4A] leading-tight">$4.2M</div>
                    <div className="text-sm font-semibold text-gray-700">Allocated</div>
                  </div>
                </div>

                {/* Network Safety */}
                <div className="bg-white border border-gray-100 rounded-3xl p-6 flex items-center gap-5 shadow-sm">
                  <div className="w-14 h-14 rounded-full bg-[#FFE4F2] flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-6 h-6 text-[#E94E8B]" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-gray-500 mb-1 uppercase tracking-wider">Network Safety</div>
                    <div className="text-2xl font-bold text-[#2D2A4A] leading-tight">Grade A+</div>
                  </div>
                </div>
              </div>

            </div>

            {/* RIGHT COLUMN */}
            <div className="col-span-1 lg:col-span-5 flex flex-col gap-6">
              
              {/* Explanation Card */}
              <div className="bg-white border border-gray-100 rounded-3xl p-8 shadow-sm">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-full bg-[#7C6CF6] flex items-center justify-center shrink-0 shadow-sm shadow-purple-500/20">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-[#2D2A4A]">Why this route is optimal</h3>
                </div>

                <div className="space-y-5 text-sm text-gray-600 leading-relaxed mb-8">
                  <p>
                    The GAF engine prioritized this multi-hop sequence to leverage <span className="font-bold text-[#2D2A4A]">Singapore's current low-latency banking gateway</span>, reducing settlement time by 14 hours compared to direct routing.
                  </p>
                  <p>
                    The transit through UAE serves as a strategic liquidity hedge, offsetting regional volatility while maintaining a <span className="font-bold text-[#2D2A4A]">fixed-spread cost structure</span> during the high-volume window.
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#7C6CF6] shrink-0 mt-0.5" />
                    <p className="text-sm text-gray-600 font-medium">Reduced intermediary fees via established corridor partners.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#7C6CF6] shrink-0 mt-0.5" />
                    <p className="text-sm text-gray-600 font-medium">Mitigated FX slippage by 0.14% using predictive hedging.</p>
                  </div>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-4">
                
                {/* Total Cost Efficiency */}
                <div className="bg-[#6D5DF5] rounded-3xl p-6 text-white shadow-sm flex flex-col justify-between h-44">
                  <div className="text-[11px] font-bold text-white/80 uppercase tracking-wider leading-tight">Total Cost<br/>Efficiency</div>
                  <div>
                    <div className="text-4xl font-bold mb-3">94.8 <span className="text-xl font-semibold">%</span></div>
                    <div className="inline-flex items-center gap-1.5 bg-white/20 rounded-full px-3 py-1.5 text-[10px] font-semibold">
                      <TrendingUp className="w-3 h-3" />
                      +4.2% vs Benchmark
                    </div>
                  </div>
                </div>

                {/* Risk Level */}
                <div className="bg-[#F3E8FF] rounded-3xl p-6 shadow-sm flex flex-col justify-between h-44">
                  <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Risk Level</div>
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-3.5 h-3.5 rounded-full bg-green-600"></div>
                      <div className="text-3xl font-bold text-[#2D2A4A]">Low</div>
                    </div>
                    <div className="text-[11px] text-gray-500 font-medium leading-tight">Continuous monitoring<br/>active</div>
                  </div>
                </div>

                {/* Estimated Time */}
                <div className="bg-[#F8F5FF] rounded-3xl p-6 shadow-sm flex flex-col justify-between h-44">
                  <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Estimated Time</div>
                  <div>
                    <div className="text-4xl font-bold text-[#2D2A4A] mb-3">2.4 <span className="text-lg font-semibold text-gray-600">hrs</span></div>
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#6D5DF5]">
                      <Zap className="w-3.5 h-3.5 fill-current" />
                      Fastest Route Available
                    </div>
                  </div>
                </div>

                {/* Efficiency Score */}
                <div className="bg-[#EBE4FF] rounded-3xl p-6 shadow-sm flex flex-col justify-between h-44">
                  <div className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Efficiency Score</div>
                  <div>
                    <div className="text-4xl font-bold text-[#6D5DF5] mb-3">98 <span className="text-lg font-semibold text-[#6D5DF5]/70">/100</span></div>
                    <div className="text-[11px] text-gray-500 font-medium leading-tight">Peak performance<br/>achieved</div>
                  </div>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="flex flex-col gap-3 mt-2">
                <button className="w-full bg-[#6D5DF5] hover:bg-[#5B4BE0] text-white py-4 rounded-full font-bold flex items-center justify-center gap-2 transition-colors shadow-md shadow-purple-500/20 text-[15px]">
                  Execute Asset Flow <ArrowRight className="w-5 h-5" />
                </button>
                <button 
                  onClick={() => setResult(false)}
                  className="w-full bg-white border-2 border-[#EBE4FF] hover:bg-[#F8F5FF] text-[#6D5DF5] py-4 rounded-full font-bold transition-colors text-[15px]"
                >
                  Review Alternative Paths
                </button>
              </div>

            </div>
          </div>
        )}
      </div>
    </PageWrapper>
  );
}
